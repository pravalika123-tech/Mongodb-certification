package com.hospital.hms.security;

import com.hospital.hms.document.Role;
import lombok.Getter;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.List;

/**
 * Spring Security's UserDetails implementation, wrapping whichever
 * role-document (Patient/Doctor/Admin/Pharmacist/Receptionist) was
 * found during authentication.
 *
 * We don't store the actual document type here - just the fields
 * Spring Security needs, plus the underlying document's ID so
 * controllers can fetch the full profile if needed.
 */
@Getter
public class UserPrincipal implements UserDetails {

    private final String id;
    private final String username;
    private final String password;
    private final Role role;

    public UserPrincipal(String id, String username, String password, Role role) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {
        // Spring Security convention: prefix roles with "ROLE_"
        return List.of(new SimpleGrantedAuthority("ROLE_" + role.name()));
    }

    @Override
    public String getPassword() {
        return password;
    }

    @Override
    public String getUsername() {
        return username;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}
