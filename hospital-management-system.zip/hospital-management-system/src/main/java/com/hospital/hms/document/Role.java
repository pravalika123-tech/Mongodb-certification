package com.hospital.hms.document;

/**
 * Defines the system roles used for authentication and authorization.
 * Each role corresponds to a separate MongoDB collection
 * (Admin, Doctor, Patient, Pharmacist, Receptionist).
 */
public enum Role {
    ADMIN,
    DOCTOR,
    PATIENT,
    PHARMACIST,
    RECEPTIONIST
}
