package com.hospital.hms.repository;

import com.hospital.hms.document.Appointment;
import com.hospital.hms.document.AppointmentStatus;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.time.LocalDate;
import java.util.List;

public interface AppointmentRepository extends MongoRepository<Appointment, String> {

    // All appointments for a given patient (patient's own history)
    List<Appointment> findByPatientId(String patientId);

    // All appointments for a given doctor (doctor's full schedule)
    List<Appointment> findByDoctorId(String doctorId);

    // A doctor's schedule for one specific day
    List<Appointment> findByDoctorIdAndAppointmentDate(String doctorId, LocalDate appointmentDate);

    // A patient's appointments filtered by status (e.g. upcoming = SCHEDULED/CONFIRMED)
    List<Appointment> findByPatientIdAndStatus(String patientId, AppointmentStatus status);

    // A doctor's appointments filtered by status
    List<Appointment> findByDoctorIdAndStatus(String doctorId, AppointmentStatus status);

    // Check for double-booking before creating a new appointment
    boolean existsByDoctorIdAndAppointmentDateAndAppointmentTime(
            String doctorId, LocalDate appointmentDate, java.time.LocalTime appointmentTime);
}
