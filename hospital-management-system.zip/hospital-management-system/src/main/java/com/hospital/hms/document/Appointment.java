package com.hospital.hms.document;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;
import java.time.LocalTime;

/**
 * Appointment document - links a Patient and a Doctor by reference (ID),
 * rather than embedding, so doctors can efficiently query their own
 * schedule (e.g. findByDoctorIdAndAppointmentDate).
 *
 * Collection: "appointments"
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "appointments")
public class Appointment {

    @Id
    private String id;

    @Indexed
    @NotBlank(message = "Patient ID is required")
    private String patientId;

    @Indexed
    @NotBlank(message = "Doctor ID is required")
    private String doctorId;

    @NotNull(message = "Appointment date is required")
    private LocalDate appointmentDate;

    @NotNull(message = "Appointment time is required")
    private LocalTime appointmentTime;

    private String reasonForVisit;

    private AppointmentStatus status = AppointmentStatus.SCHEDULED;

    private String notes;

    // Denormalized fields for quick display without an extra lookup
    // (kept in sync when patient/doctor profile changes, or refreshed on read)
    private String patientName;

    private String doctorName;

    private String createdAt;
}
