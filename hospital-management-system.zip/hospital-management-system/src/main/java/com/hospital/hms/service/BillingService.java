package com.hospital.hms.service;

import com.hospital.hms.document.Billing;
import com.hospital.hms.dto.BillingRequest;
import com.hospital.hms.repository.BillingRepository;
import com.hospital.hms.repository.PatientRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class BillingService {

    private final BillingRepository billingRepository;
    private final PatientRepository patientRepository;

    // Generate a bill
    public Billing generateBill(BillingRequest request) {
        patientRepository.findById(request.getPatientId())
                .orElseThrow(() -> new IllegalArgumentException(
                        "Patient not found: " + request.getPatientId()));

        List<Billing.BillItem> items = request.getItems().stream()
                .map(i -> new Billing.BillItem(i.getDescription(), i.getAmount(), i.getQuantity()))
                .collect(Collectors.toList());

        double total = items.stream()
                .mapToDouble(i -> i.getAmount() * i.getQuantity())
                .sum();

        Billing billing = new Billing();
        billing.setPatientId(request.getPatientId());
        billing.setAppointmentId(request.getAppointmentId());
        billing.setItems(items);
        billing.setTotalAmount(total);
        billing.setPaymentStatus(Billing.PaymentStatus.PENDING);
        billing.setPaymentMethod(request.getPaymentMethod());
        billing.setGeneratedAt(LocalDateTime.now().toString());

        return billingRepository.save(billing);
    }

    // Mark bill as paid
    public Billing markAsPaid(String billingId) {
        Billing billing = getById(billingId);
        billing.setPaymentStatus(Billing.PaymentStatus.PAID);
        billing.setPaidAt(LocalDateTime.now().toString());
        return billingRepository.save(billing);
    }

    // Get all bills for a patient
    public List<Billing> getByPatient(String patientId) {
        return billingRepository.findByPatientId(patientId);
    }

    // Get bills by payment status
    public List<Billing> getByStatus(Billing.PaymentStatus status) {
        return billingRepository.findByPaymentStatus(status);
    }

    // Get all bills (Admin)
    public List<Billing> getAll() {
        return billingRepository.findAll();
    }

    // Get bill by ID
    public Billing getById(String id) {
        return billingRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Bill not found: " + id));
    }
}
