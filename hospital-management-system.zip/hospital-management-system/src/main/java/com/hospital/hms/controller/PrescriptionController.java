package com.hospital.hms.controller;

import com.hospital.hms.document.Prescription;
import com.hospital.hms.dto.ApiResponse;
import com.hospital.hms.dto.PrescriptionRequest;
import com.hospital.hms.security.UserPrincipal;
import com.hospital.hms.service.PrescriptionService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/prescriptions")
@RequiredArgsConstructor
@Tag(name = "Prescriptions", description = "Prescription issuance and dispensing")
@SecurityRequirement(name = "bearerAuth")
public class PrescriptionController {

    private final PrescriptionService prescriptionService;

    // Doctor issues a prescription (doctor's own ID is read from JWT)
    @Operation(summary = "Issue a prescription (Doctor only)")
    @PreAuthorize("hasRole('DOCTOR')")
    @PostMapping
    public ResponseEntity<ApiResponse> issuePrescription(
            @Valid @RequestBody PrescriptionRequest request,
            @AuthenticationPrincipal UserPrincipal doctor) {
        Prescription prescription = prescriptionService.issuePrescription(doctor.getId(), request);
        return ResponseEntity.ok(ApiResponse.ok("Prescription issued", prescription));
    }

    // Pharmacist's worklist - all undispensed prescriptions
    @Operation(summary = "Get all pending (undispensed) prescriptions (Pharmacist only)")
    @PreAuthorize("hasAnyRole('PHARMACIST','ADMIN')")
    @GetMapping("/pending")
    public ResponseEntity<ApiResponse> getPending() {
        List<Prescription> prescriptions = prescriptionService.getPendingPrescriptions();
        return ResponseEntity.ok(ApiResponse.ok("Pending prescriptions", prescriptions));
    }

    // Pharmacist dispenses a prescription
    @Operation(summary = "Mark prescription as dispensed (Pharmacist only)")
    @PreAuthorize("hasRole('PHARMACIST')")
    @PatchMapping("/{id}/dispense")
    public ResponseEntity<ApiResponse> dispense(
            @PathVariable String id,
            @AuthenticationPrincipal UserPrincipal pharmacist) {
        Prescription prescription = prescriptionService.dispensePrescription(id, pharmacist.getId());
        return ResponseEntity.ok(ApiResponse.ok("Prescription dispensed", prescription));
    }

    // Get by ID
    @Operation(summary = "Get prescription by ID")
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','PHARMACIST','PATIENT')")
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse> getById(@PathVariable String id) {
        return ResponseEntity.ok(ApiResponse.ok("Prescription retrieved",
                prescriptionService.getById(id)));
    }

    // Get prescription by appointment
    @Operation(summary = "Get prescription by appointment ID")
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','PHARMACIST','PATIENT')")
    @GetMapping("/appointment/{appointmentId}")
    public ResponseEntity<ApiResponse> getByAppointment(@PathVariable String appointmentId) {
        return ResponseEntity.ok(ApiResponse.ok("Prescription retrieved",
                prescriptionService.getByAppointment(appointmentId)));
    }

    // Get all prescriptions for a patient
    @Operation(summary = "Get all prescriptions for a patient")
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','PHARMACIST','PATIENT')")
    @GetMapping("/patient/{patientId}")
    public ResponseEntity<ApiResponse> getByPatient(@PathVariable String patientId) {
        List<Prescription> prescriptions = prescriptionService.getByPatient(patientId);
        return ResponseEntity.ok(ApiResponse.ok("Prescriptions retrieved", prescriptions));
    }

    // Get all prescriptions by doctor
    @Operation(summary = "Get all prescriptions issued by a doctor")
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR')")
    @GetMapping("/doctor/{doctorId}")
    public ResponseEntity<ApiResponse> getByDoctor(@PathVariable String doctorId) {
        List<Prescription> prescriptions = prescriptionService.getByDoctor(doctorId);
        return ResponseEntity.ok(ApiResponse.ok("Prescriptions retrieved", prescriptions));
    }
}
