package com.hospital.hms.service;

import com.hospital.hms.document.Appointment;
import com.hospital.hms.document.AppointmentStatus;
import com.hospital.hms.document.Prescription;
import com.hospital.hms.dto.PrescriptionRequest;
import com.hospital.hms.repository.AppointmentRepository;
import com.hospital.hms.repository.PrescriptionRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PrescriptionService {

    private final PrescriptionRepository prescriptionRepository;
    private final AppointmentRepository appointmentRepository;

    // Doctor issues a prescription after a completed/confirmed appointment
    public Prescription issuePrescription(String doctorId, PrescriptionRequest request) {
        Appointment appointment = appointmentRepository.findById(request.getAppointmentId())
                .orElseThrow(() -> new IllegalArgumentException(
                        "Appointment not found: " + request.getAppointmentId()));

        if (!appointment.getDoctorId().equals(doctorId)) {
            throw new IllegalArgumentException(
                    "You can only issue prescriptions for your own appointments");
        }

        // Prevent duplicate prescriptions for the same appointment
        prescriptionRepository.findByAppointmentId(request.getAppointmentId())
                .ifPresent(p -> { throw new IllegalArgumentException(
                        "A prescription already exists for this appointment"); });

        List<Prescription.Medicine> medicines = request.getMedicines().stream()
                .map(m -> new Prescription.Medicine(
                        m.getName(), m.getDosage(), m.getFrequency(),
                        m.getDuration(), m.getInstructions()))
                .collect(Collectors.toList());

        Prescription prescription = new Prescription();
        prescription.setAppointmentId(request.getAppointmentId());
        prescription.setPatientId(request.getPatientId());
        prescription.setDoctorId(doctorId);
        prescription.setMedicines(medicines);
        prescription.setDiagnosis(request.getDiagnosis());
        prescription.setAdditionalNotes(request.getAdditionalNotes());
        prescription.setDispensed(false);
        prescription.setIssuedAt(LocalDateTime.now().toString());

        // Mark appointment as completed
        appointment.setStatus(AppointmentStatus.COMPLETED);
        appointmentRepository.save(appointment);

        return prescriptionRepository.save(prescription);
    }

    // Pharmacist views all undispensed prescriptions (their worklist)
    public List<Prescription> getPendingPrescriptions() {
        return prescriptionRepository.findByDispensedFalse();
    }

    // Pharmacist marks a prescription as dispensed
    public Prescription dispensePrescription(String prescriptionId, String pharmacistId) {
        Prescription prescription = prescriptionRepository.findById(prescriptionId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Prescription not found: " + prescriptionId));

        if (prescription.isDispensed()) {
            throw new IllegalArgumentException("This prescription has already been dispensed");
        }

        prescription.setDispensed(true);
        prescription.setDispensedByPharmacistId(pharmacistId);
        return prescriptionRepository.save(prescription);
    }

    // Get all prescriptions for a patient
    public List<Prescription> getByPatient(String patientId) {
        return prescriptionRepository.findByPatientId(patientId);
    }

    // Get all prescriptions issued by a doctor
    public List<Prescription> getByDoctor(String doctorId) {
        return prescriptionRepository.findByDoctorId(doctorId);
    }

    // Get prescription by ID
    public Prescription getById(String id) {
        return prescriptionRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Prescription not found: " + id));
    }

    // Get prescription linked to an appointment
    public Prescription getByAppointment(String appointmentId) {
        return prescriptionRepository.findByAppointmentId(appointmentId)
                .orElseThrow(() -> new IllegalArgumentException(
                        "No prescription found for appointment: " + appointmentId));
    }
}
