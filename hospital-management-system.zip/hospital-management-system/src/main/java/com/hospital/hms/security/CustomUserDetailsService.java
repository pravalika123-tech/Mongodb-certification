package com.hospital.hms.security;

import com.hospital.hms.document.*;
import com.hospital.hms.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import java.util.Optional;

/**
 * Looks up a username across all five role collections (since each role
 * has its own collection with embedded auth fields, rather than one
 * shared "users" collection).
 *
 * Order of lookup: Admin -> Doctor -> Patient -> Pharmacist -> Receptionist.
 * Usernames are expected to be unique across the whole system (enforced
 * at the application level in the registration service, since MongoDB's
 * unique index only applies per-collection).
 */
@Service
@RequiredArgsConstructor
public class CustomUserDetailsService implements UserDetailsService {

    private final AdminRepository adminRepository;
    private final DoctorRepository doctorRepository;
    private final PatientRepository patientRepository;
    private final PharmacistRepository pharmacistRepository;
    private final ReceptionistRepository receptionistRepository;

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {

        Optional<Admin> admin = adminRepository.findByUsername(username);
        if (admin.isPresent()) {
            Admin a = admin.get();
            return new UserPrincipal(a.getId(), a.getUsername(), a.getPassword(), Role.ADMIN);
        }

        Optional<Doctor> doctor = doctorRepository.findByUsername(username);
        if (doctor.isPresent()) {
            Doctor d = doctor.get();
            return new UserPrincipal(d.getId(), d.getUsername(), d.getPassword(), Role.DOCTOR);
        }

        Optional<Patient> patient = patientRepository.findByUsername(username);
        if (patient.isPresent()) {
            Patient p = patient.get();
            return new UserPrincipal(p.getId(), p.getUsername(), p.getPassword(), Role.PATIENT);
        }

        Optional<Pharmacist> pharmacist = pharmacistRepository.findByUsername(username);
        if (pharmacist.isPresent()) {
            Pharmacist ph = pharmacist.get();
            return new UserPrincipal(ph.getId(), ph.getUsername(), ph.getPassword(), Role.PHARMACIST);
        }

        Optional<Receptionist> receptionist = receptionistRepository.findByUsername(username);
        if (receptionist.isPresent()) {
            Receptionist r = receptionist.get();
            return new UserPrincipal(r.getId(), r.getUsername(), r.getPassword(), Role.RECEPTIONIST);
        }

        throw new UsernameNotFoundException("No user found with username: " + username);
    }
}
