package com.hospital.hms.service;

import com.hospital.hms.document.*;
import com.hospital.hms.dto.*;
import com.hospital.hms.repository.*;
import com.hospital.hms.security.JwtUtil;
import com.hospital.hms.security.UserPrincipal;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final AuthenticationManager authenticationManager;
    private final JwtUtil jwtUtil;
    private final PasswordEncoder passwordEncoder;

    private final AdminRepository adminRepository;
    private final DoctorRepository doctorRepository;
    private final PatientRepository patientRepository;
    private final PharmacistRepository pharmacistRepository;
    private final ReceptionistRepository receptionistRepository;

    // ─────────────────────────────────────────────
    // LOGIN (works for all roles)
    // ─────────────────────────────────────────────

    public JwtResponse login(LoginRequest request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getUsername(), request.getPassword()));

        UserPrincipal principal = (UserPrincipal) authentication.getPrincipal();
        String token = jwtUtil.generateToken(principal);

        return new JwtResponse(
                token,
                "Bearer",
                principal.getId(),
                principal.getUsername(),
                principal.getRole().name());
    }

    // ─────────────────────────────────────────────
    // CROSS-COLLECTION USERNAME UNIQUENESS CHECK
    // ─────────────────────────────────────────────

    private void assertUsernameNotTaken(String username) {
        if (adminRepository.existsByUsername(username)
                || doctorRepository.existsByUsername(username)
                || patientRepository.existsByUsername(username)
                || pharmacistRepository.existsByUsername(username)
                || receptionistRepository.existsByUsername(username)) {
            throw new IllegalArgumentException(
                    "Username '" + username + "' is already taken across the system");
        }
    }

    // ─────────────────────────────────────────────
    // REGISTER PATIENT (self-registration)
    // ─────────────────────────────────────────────

    public String registerPatient(RegisterPatientRequest request) {
        assertUsernameNotTaken(request.getUsername());

        Patient patient = new Patient();
        patient.setUsername(request.getUsername());
        patient.setPassword(passwordEncoder.encode(request.getPassword()));
        patient.setRole(Role.PATIENT);
        patient.setFullName(request.getFullName());
        patient.setEmail(request.getEmail());
        patient.setPhoneNumber(request.getPhoneNumber());
        patient.setDateOfBirth(request.getDateOfBirth());
        patient.setGender(request.getGender());
        patient.setAddress(request.getAddress());
        patient.setBloodGroup(request.getBloodGroup());
        patient.setEmergencyContactName(request.getEmergencyContactName());
        patient.setEmergencyContactPhone(request.getEmergencyContactPhone());

        patientRepository.save(patient);
        return "Patient registered successfully";
    }

    // ─────────────────────────────────────────────
    // REGISTER DOCTOR (Admin only)
    // ─────────────────────────────────────────────

    public String registerDoctor(RegisterDoctorRequest request) {
        assertUsernameNotTaken(request.getUsername());

        Doctor doctor = new Doctor();
        doctor.setUsername(request.getUsername());
        doctor.setPassword(passwordEncoder.encode(request.getPassword()));
        doctor.setRole(Role.DOCTOR);
        doctor.setFullName(request.getFullName());
        doctor.setEmail(request.getEmail());
        doctor.setPhoneNumber(request.getPhoneNumber());
        doctor.setSpecialization(request.getSpecialization());
        doctor.setQualification(request.getQualification());
        doctor.setYearsOfExperience(request.getYearsOfExperience());
        doctor.setAvailableDays(request.getAvailableDays());
        doctor.setAvailableTimeStart(request.getAvailableTimeStart());
        doctor.setAvailableTimeEnd(request.getAvailableTimeEnd());
        doctor.setConsultationFee(request.getConsultationFee());

        doctorRepository.save(doctor);
        return "Doctor registered successfully";
    }

    // ─────────────────────────────────────────────
    // REGISTER ADMIN (Admin only)
    // ─────────────────────────────────────────────

    public String registerAdmin(RegisterAdminRequest request) {
        assertUsernameNotTaken(request.getUsername());

        Admin admin = new Admin();
        admin.setUsername(request.getUsername());
        admin.setPassword(passwordEncoder.encode(request.getPassword()));
        admin.setRole(Role.ADMIN);
        admin.setFullName(request.getFullName());
        admin.setEmail(request.getEmail());
        admin.setPhoneNumber(request.getPhoneNumber());

        adminRepository.save(admin);
        return "Admin registered successfully";
    }

    // ─────────────────────────────────────────────
    // REGISTER PHARMACIST (Admin only)
    // ─────────────────────────────────────────────

    public String registerPharmacist(RegisterPharmacistRequest request) {
        assertUsernameNotTaken(request.getUsername());

        Pharmacist pharmacist = new Pharmacist();
        pharmacist.setUsername(request.getUsername());
        pharmacist.setPassword(passwordEncoder.encode(request.getPassword()));
        pharmacist.setRole(Role.PHARMACIST);
        pharmacist.setFullName(request.getFullName());
        pharmacist.setEmail(request.getEmail());
        pharmacist.setPhoneNumber(request.getPhoneNumber());
        pharmacist.setLicenseNumber(request.getLicenseNumber());

        pharmacistRepository.save(pharmacist);
        return "Pharmacist registered successfully";
    }

    // ─────────────────────────────────────────────
    // REGISTER RECEPTIONIST (Admin only)
    // ─────────────────────────────────────────────

    public String registerReceptionist(RegisterReceptionistRequest request) {
        assertUsernameNotTaken(request.getUsername());

        Receptionist receptionist = new Receptionist();
        receptionist.setUsername(request.getUsername());
        receptionist.setPassword(passwordEncoder.encode(request.getPassword()));
        receptionist.setRole(Role.RECEPTIONIST);
        receptionist.setFullName(request.getFullName());
        receptionist.setEmail(request.getEmail());
        receptionist.setPhoneNumber(request.getPhoneNumber());

        receptionistRepository.save(receptionist);
        return "Receptionist registered successfully";
    }
}
