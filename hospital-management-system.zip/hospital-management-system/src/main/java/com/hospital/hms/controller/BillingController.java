package com.hospital.hms.controller;

import com.hospital.hms.document.Billing;
import com.hospital.hms.dto.ApiResponse;
import com.hospital.hms.dto.BillingRequest;
import com.hospital.hms.service.BillingService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/billing")
@RequiredArgsConstructor
@Tag(name = "Billing", description = "Bill generation and payment management")
@SecurityRequirement(name = "bearerAuth")
public class BillingController {

    private final BillingService billingService;

    @Operation(summary = "Generate a bill for a patient (Admin/Receptionist)")
    @PreAuthorize("hasAnyRole('ADMIN','RECEPTIONIST')")
    @PostMapping
    public ResponseEntity<ApiResponse> generateBill(@Valid @RequestBody BillingRequest request) {
        Billing bill = billingService.generateBill(request);
        return ResponseEntity.ok(ApiResponse.ok("Bill generated", bill));
    }

    @Operation(summary = "Get all bills (Admin only)")
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public ResponseEntity<ApiResponse> getAll() {
        List<Billing> bills = billingService.getAll();
        return ResponseEntity.ok(ApiResponse.ok("Bills retrieved", bills));
    }

    @Operation(summary = "Get bill by ID")
    @PreAuthorize("hasAnyRole('ADMIN','RECEPTIONIST','PATIENT')")
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse> getById(@PathVariable String id) {
        return ResponseEntity.ok(ApiResponse.ok("Bill retrieved", billingService.getById(id)));
    }

    @Operation(summary = "Get all bills for a patient")
    @PreAuthorize("hasAnyRole('ADMIN','RECEPTIONIST','PATIENT')")
    @GetMapping("/patient/{patientId}")
    public ResponseEntity<ApiResponse> getByPatient(@PathVariable String patientId) {
        List<Billing> bills = billingService.getByPatient(patientId);
        return ResponseEntity.ok(ApiResponse.ok("Bills retrieved", bills));
    }

    @Operation(summary = "Get bills by payment status (PENDING, PAID, PARTIALLY_PAID, CANCELLED)")
    @PreAuthorize("hasAnyRole('ADMIN','RECEPTIONIST')")
    @GetMapping("/status/{status}")
    public ResponseEntity<ApiResponse> getByStatus(@PathVariable Billing.PaymentStatus status) {
        List<Billing> bills = billingService.getByStatus(status);
        return ResponseEntity.ok(ApiResponse.ok("Bills retrieved", status.name(), bills));
    }

    @Operation(summary = "Mark a bill as paid (Admin/Receptionist)")
    @PreAuthorize("hasAnyRole('ADMIN','RECEPTIONIST')")
    @PatchMapping("/{id}/pay")
    public ResponseEntity<ApiResponse> markAsPaid(@PathVariable String id) {
        Billing bill = billingService.markAsPaid(id);
        return ResponseEntity.ok(ApiResponse.ok("Bill marked as paid", bill));
    }
}
