package com.hospital.hms.document;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.time.LocalDate;

/**
 * Patient document - represents both the patient's profile and their
 * login credentials (username/password/role embedded directly).
 *
 * Collection: "patients"
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "patients")
public class Patient {

    @Id
    private String id;

    // ---- Auth fields ----
    @Indexed(unique = true)
    @NotBlank(message = "Username is required")
    private String username;

    @NotBlank(message = "Password is required")
    private String password; // stored as a BCrypt hash, never plain text

    private Role role = Role.PATIENT;

    // ---- Profile fields ----
    @NotBlank(message = "Full name is required")
    private String fullName;

    @Email(message = "Email should be valid")
    private String email;

    private String phoneNumber;

    private LocalDate dateOfBirth;

    private String gender;

    private String address;

    private String bloodGroup;

    private String emergencyContactName;

    private String emergencyContactPhone;
}
