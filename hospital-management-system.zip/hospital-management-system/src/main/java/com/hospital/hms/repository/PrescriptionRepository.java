package com.hospital.hms.repository;

import com.hospital.hms.document.Prescription;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface PrescriptionRepository extends MongoRepository<Prescription, String> {

    Optional<Prescription> findByAppointmentId(String appointmentId);

    List<Prescription> findByPatientId(String patientId);

    List<Prescription> findByDoctorId(String doctorId);

    // For the Pharmacist's worklist - prescriptions not yet dispensed
    List<Prescription> findByDispensedFalse();
}
