package com.hospital.hms.repository;

import com.hospital.hms.document.Receptionist;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface ReceptionistRepository extends MongoRepository<Receptionist, String> {

    Optional<Receptionist> findByUsername(String username);

    boolean existsByUsername(String username);
}
