package com.hospital.hms.repository;

import com.hospital.hms.document.Doctor;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;
import java.util.Optional;

public interface DoctorRepository extends MongoRepository<Doctor, String> {

    Optional<Doctor> findByUsername(String username);

    boolean existsByUsername(String username);

    List<Doctor> findBySpecializationIgnoreCase(String specialization);
}
