package com.hospital.hms.repository;

import com.hospital.hms.document.Patient;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface PatientRepository extends MongoRepository<Patient, String> {

    Optional<Patient> findByUsername(String username);

    boolean existsByUsername(String username);
}
