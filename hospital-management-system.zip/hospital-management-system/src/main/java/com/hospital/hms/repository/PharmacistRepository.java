package com.hospital.hms.repository;

import com.hospital.hms.document.Pharmacist;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.Optional;

public interface PharmacistRepository extends MongoRepository<Pharmacist, String> {

    Optional<Pharmacist> findByUsername(String username);

    boolean existsByUsername(String username);
}
