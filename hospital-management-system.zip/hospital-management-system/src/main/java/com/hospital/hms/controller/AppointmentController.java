package com.hospital.hms.controller;

import com.hospital.hms.document.Appointment;
import com.hospital.hms.document.AppointmentStatus;
import com.hospital.hms.dto.ApiResponse;
import com.hospital.hms.dto.AppointmentRequest;
import com.hospital.hms.service.AppointmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

@RestController
@RequestMapping("/api/v1/appointments")
@RequiredArgsConstructor
@Tag(name = "Appointments", description = "Appointment booking and management")
@SecurityRequirement(name = "bearerAuth")
public class AppointmentController {

    private final AppointmentService appointmentService;

    // Book a new appointment
    // Receptionist or Patient can book
    @Operation(summary = "Book a new appointment")
    @PreAuthorize("hasAnyRole('RECEPTIONIST','PATIENT','ADMIN')")
    @PostMapping
    public ResponseEntity<ApiResponse> bookAppointment(
            @Valid @RequestBody AppointmentRequest request) {
        Appointment appointment = appointmentService.bookAppointment(request);
        return ResponseEntity.ok(ApiResponse.ok("Appointment booked successfully", appointment));
    }

    // Get all appointments (Admin only)
    @Operation(summary = "Get all appointments (Admin only)")
    @PreAuthorize("hasRole('ADMIN')")
    @GetMapping
    public ResponseEntity<ApiResponse> getAllAppointments() {
        List<Appointment> appointments = appointmentService.getAllAppointments();
        return ResponseEntity.ok(ApiResponse.ok("Appointments retrieved", appointments));
    }

    // Get appointment by ID
    @Operation(summary = "Get appointment by ID")
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','PATIENT','RECEPTIONIST')")
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse> getAppointmentById(@PathVariable String id) {
        Appointment appointment = appointmentService.getAppointmentById(id);
        return ResponseEntity.ok(ApiResponse.ok("Appointment retrieved", appointment));
    }

    // Get all appointments for a patient
    @Operation(summary = "Get all appointments for a specific patient")
    @PreAuthorize("hasAnyRole('ADMIN','RECEPTIONIST','PATIENT','DOCTOR')")
    @GetMapping("/patient/{patientId}")
    public ResponseEntity<ApiResponse> getByPatient(@PathVariable String patientId) {
        List<Appointment> appointments = appointmentService.getAppointmentsByPatient(patientId);
        return ResponseEntity.ok(ApiResponse.ok("Patient appointments retrieved", appointments));
    }

    // Get all appointments for a doctor
    @Operation(summary = "Get all appointments for a specific doctor")
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','RECEPTIONIST')")
    @GetMapping("/doctor/{doctorId}")
    public ResponseEntity<ApiResponse> getByDoctor(@PathVariable String doctorId) {
        List<Appointment> appointments = appointmentService.getAppointmentsByDoctor(doctorId);
        return ResponseEntity.ok(ApiResponse.ok("Doctor appointments retrieved", appointments));
    }

    // Get doctor's schedule for a specific date
    @Operation(summary = "Get doctor's schedule for a specific date (YYYY-MM-DD)")
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','RECEPTIONIST')")
    @GetMapping("/doctor/{doctorId}/schedule")
    public ResponseEntity<ApiResponse> getDoctorSchedule(
            @PathVariable String doctorId,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate date) {
        List<Appointment> appointments = appointmentService.getDoctorScheduleForDate(doctorId, date);
        return ResponseEntity.ok(ApiResponse.ok("Schedule retrieved", appointments));
    }

    // Update appointment status
    @Operation(summary = "Update appointment status (CONFIRMED, COMPLETED, CANCELLED, NO_SHOW)")
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','RECEPTIONIST')")
    @PatchMapping("/{id}/status")
    public ResponseEntity<ApiResponse> updateStatus(
            @PathVariable String id,
            @RequestParam AppointmentStatus status) {
        Appointment updated = appointmentService.updateStatus(id, status);
        return ResponseEntity.ok(ApiResponse.ok("Appointment status updated", updated));
    }

    // Cancel appointment
    @Operation(summary = "Cancel an appointment")
    @PreAuthorize("hasAnyRole('ADMIN','DOCTOR','RECEPTIONIST','PATIENT')")
    @PatchMapping("/{id}/cancel")
    public ResponseEntity<ApiResponse> cancelAppointment(@PathVariable String id) {
        Appointment cancelled = appointmentService.cancelAppointment(id);
        return ResponseEntity.ok(ApiResponse.ok("Appointment cancelled", cancelled));
    }

    // Delete appointment (Admin only)
    @Operation(summary = "Delete an appointment (Admin only)")
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> deleteAppointment(@PathVariable String id) {
        appointmentService.deleteAppointment(id);
        return ResponseEntity.ok(ApiResponse.ok("Appointment deleted"));
    }
}
