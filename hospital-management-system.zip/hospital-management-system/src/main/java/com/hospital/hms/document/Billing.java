package com.hospital.hms.document;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

/**
 * Billing document - an invoice tied to a Patient and (optionally) a
 * specific Appointment. Line items are embedded since they only make
 * sense within their own bill.
 *
 * Collection: "billings"
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "billings")
public class Billing {

    @Id
    private String id;

    @Indexed
    @NotBlank(message = "Patient ID is required")
    private String patientId;

    private String appointmentId; // optional - bill may cover more than one visit

    @NotNull(message = "Line items are required")
    private List<BillItem> items;

    private double totalAmount;

    private PaymentStatus paymentStatus = PaymentStatus.PENDING;

    private String paymentMethod; // e.g. "CASH", "CARD", "INSURANCE"

    private String generatedAt;

    private String paidAt;

    /**
     * Embedded sub-document for a single billable line item.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class BillItem {
        private String description; // e.g. "Consultation Fee", "X-Ray", "Medicine"
        private double amount;
        private int quantity = 1;
    }

    public enum PaymentStatus {
        PENDING,
        PAID,
        PARTIALLY_PAID,
        CANCELLED
    }
}
