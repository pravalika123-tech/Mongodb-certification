package com.hospital.hms.repository;

import com.hospital.hms.document.Billing;
import org.springframework.data.mongodb.repository.MongoRepository;

import java.util.List;

public interface BillingRepository extends MongoRepository<Billing, String> {

    List<Billing> findByPatientId(String patientId);

    List<Billing> findByAppointmentId(String appointmentId);

    List<Billing> findByPaymentStatus(Billing.PaymentStatus paymentStatus);
}
