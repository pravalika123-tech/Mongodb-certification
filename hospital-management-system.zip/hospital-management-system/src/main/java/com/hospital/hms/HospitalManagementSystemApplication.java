package com.hospital.hms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Entry point for the Hospital Management System REST API.
 *
 * Stack: Spring Boot + Spring Data MongoDB + Spring Security (JWT)
 * No frontend - test via Postman or Swagger UI (/swagger-ui.html)
 */
@SpringBootApplication
public class HospitalManagementSystemApplication {

    public static void main(String[] args) {
        SpringApplication.run(HospitalManagementSystemApplication.class, args);
    }

}
