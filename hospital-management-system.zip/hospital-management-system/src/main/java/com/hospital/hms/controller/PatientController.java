package com.hospital.hms.controller;

import com.hospital.hms.document.Patient;
import com.hospital.hms.dto.ApiResponse;
import com.hospital.hms.repository.PatientRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/patients")
@RequiredArgsConstructor
@Tag(name = "Patients", description = "Patient profile management")
@SecurityRequirement(name = "bearerAuth")
public class PatientController {

    private final PatientRepository patientRepository;

    @Operation(summary = "Get all patients (Admin/Receptionist/Doctor only)")
    @PreAuthorize("hasAnyRole('ADMIN','RECEPTIONIST','DOCTOR')")
    @GetMapping
    public ResponseEntity<ApiResponse> getAllPatients() {
        List<Patient> patients = patientRepository.findAll();
        patients.forEach(p -> p.setPassword(null));
        return ResponseEntity.ok(ApiResponse.ok("Patients retrieved", patients));
    }

    @Operation(summary = "Get patient by ID")
    @PreAuthorize("hasAnyRole('ADMIN','RECEPTIONIST','DOCTOR','PATIENT')")
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse> getPatientById(@PathVariable String id) {
        Patient patient = patientRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Patient not found: " + id));
        patient.setPassword(null);
        return ResponseEntity.ok(ApiResponse.ok("Patient retrieved", patient));
    }

    @Operation(summary = "Delete a patient (Admin only)")
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> deletePatient(@PathVariable String id) {
        Patient patient = patientRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Patient not found: " + id));
        patientRepository.delete(patient);
        return ResponseEntity.ok(ApiResponse.ok("Patient deleted"));
    }
}
