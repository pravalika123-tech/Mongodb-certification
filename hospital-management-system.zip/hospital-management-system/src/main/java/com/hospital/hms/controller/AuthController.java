package com.hospital.hms.controller;

import com.hospital.hms.dto.*;
import com.hospital.hms.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * Authentication and registration endpoints.
 *
 * Public:  POST /api/v1/auth/login         → any role can login
 *          POST /api/v1/auth/register/patient → patients self-register
 *
 * Admin-only (requires ADMIN JWT):
 *          POST /api/v1/auth/register/doctor
 *          POST /api/v1/auth/register/admin
 *          POST /api/v1/auth/register/pharmacist
 *          POST /api/v1/auth/register/receptionist
 */
@RestController
@RequestMapping("/api/v1/auth")
@RequiredArgsConstructor
@Tag(name = "Authentication", description = "Login and registration endpoints")
public class AuthController {

    private final AuthService authService;

    // ─── LOGIN ───────────────────────────────────────────

    @Operation(summary = "Login for all roles - returns JWT token")
    @PostMapping("/login")
    public ResponseEntity<ApiResponse> login(@Valid @RequestBody LoginRequest request) {
        JwtResponse jwt = authService.login(request);
        return ResponseEntity.ok(ApiResponse.ok("Login successful", jwt));
    }

    // ─── SELF-REGISTRATION (public) ──────────────────────

    @Operation(summary = "Register a new patient (self-registration, no auth required)")
    @PostMapping("/register/patient")
    public ResponseEntity<ApiResponse> registerPatient(
            @Valid @RequestBody RegisterPatientRequest request) {
        String msg = authService.registerPatient(request);
        return ResponseEntity.ok(ApiResponse.ok(msg));
    }

    // ─── ADMIN-ONLY REGISTRATIONS ────────────────────────

    @Operation(summary = "Register a new doctor (Admin only)")
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/register/doctor")
    public ResponseEntity<ApiResponse> registerDoctor(
            @Valid @RequestBody RegisterDoctorRequest request) {
        String msg = authService.registerDoctor(request);
        return ResponseEntity.ok(ApiResponse.ok(msg));
    }

    @Operation(summary = "Register a new admin (Admin only)")
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/register/admin")
    public ResponseEntity<ApiResponse> registerAdmin(
            @Valid @RequestBody RegisterAdminRequest request) {
        String msg = authService.registerAdmin(request);
        return ResponseEntity.ok(ApiResponse.ok(msg));
    }

    @Operation(summary = "Register a new pharmacist (Admin only)")
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/register/pharmacist")
    public ResponseEntity<ApiResponse> registerPharmacist(
            @Valid @RequestBody RegisterPharmacistRequest request) {
        String msg = authService.registerPharmacist(request);
        return ResponseEntity.ok(ApiResponse.ok(msg));
    }

    @Operation(summary = "Register a new receptionist (Admin only)")
    @PreAuthorize("hasRole('ADMIN')")
    @PostMapping("/register/receptionist")
    public ResponseEntity<ApiResponse> registerReceptionist(
            @Valid @RequestBody RegisterReceptionistRequest request) {
        String msg = authService.registerReceptionist(request);
        return ResponseEntity.ok(ApiResponse.ok(msg));
    }
}
