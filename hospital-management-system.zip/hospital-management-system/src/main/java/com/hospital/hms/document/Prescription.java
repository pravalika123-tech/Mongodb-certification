package com.hospital.hms.document;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

/**
 * Prescription document - created by a Doctor after an appointment,
 * dispensed/managed by a Pharmacist.
 *
 * Medicines are embedded since they only ever make sense in the context
 * of a single prescription (no need to query them independently).
 *
 * Collection: "prescriptions"
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "prescriptions")
public class Prescription {

    @Id
    private String id;

    @Indexed
    @NotBlank(message = "Appointment ID is required")
    private String appointmentId;

    @Indexed
    @NotBlank(message = "Patient ID is required")
    private String patientId;

    @Indexed
    @NotBlank(message = "Doctor ID is required")
    private String doctorId;

    private List<Medicine> medicines;

    private String diagnosis;

    private String additionalNotes;

    private boolean dispensed = false;

    private String dispensedByPharmacistId;

    private String issuedAt;

    /**
     * Embedded sub-document - a single medicine line item within a prescription.
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    public static class Medicine {
        private String name;
        private String dosage;     // e.g. "500mg"
        private String frequency;  // e.g. "3 times a day"
        private String duration;   // e.g. "5 days"
        private String instructions; // e.g. "after meals"
    }
}
