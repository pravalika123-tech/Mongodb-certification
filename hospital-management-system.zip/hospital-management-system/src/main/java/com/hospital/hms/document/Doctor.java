package com.hospital.hms.document;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.List;

/**
 * Doctor document - profile + login credentials embedded directly.
 *
 * Collection: "doctors"
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "doctors")
public class Doctor {

    @Id
    private String id;

    // ---- Auth fields ----
    @Indexed(unique = true)
    @NotBlank(message = "Username is required")
    private String username;

    @NotBlank(message = "Password is required")
    private String password;

    private Role role = Role.DOCTOR;

    // ---- Profile fields ----
    @NotBlank(message = "Full name is required")
    private String fullName;

    @Email(message = "Email should be valid")
    private String email;

    private String phoneNumber;

    @NotBlank(message = "Specialization is required")
    private String specialization;

    private String qualification;

    private Integer yearsOfExperience;

    // Days/time slots the doctor is available, e.g. ["MONDAY", "WEDNESDAY", "FRIDAY"]
    private List<String> availableDays;

    private String availableTimeStart; // e.g. "09:00"

    private String availableTimeEnd;   // e.g. "17:00"

    private Double consultationFee;
}
