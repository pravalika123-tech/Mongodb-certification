package com.hospital.hms.dto;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.util.List;

@Data
public class RegisterDoctorRequest {

    @NotBlank(message = "Username is required")
    private String username;

    @NotBlank(message = "Password is required")
    private String password;

    @NotBlank(message = "Full name is required")
    private String fullName;

    @Email(message = "Email should be valid")
    private String email;

    private String phoneNumber;

    @NotBlank(message = "Specialization is required")
    private String specialization;

    private String qualification;
    private Integer yearsOfExperience;
    private List<String> availableDays;
    private String availableTimeStart;
    private String availableTimeEnd;
    private Double consultationFee;
}
