package com.hospital.hms.document;

/**
 * Lifecycle states of an appointment.
 */
public enum AppointmentStatus {
    SCHEDULED,
    CONFIRMED,
    COMPLETED,
    CANCELLED,
    NO_SHOW
}
