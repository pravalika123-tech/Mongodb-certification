package com.hospital.hms.document;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * Pharmacist document - manages prescriptions and medicine dispensing.
 *
 * Collection: "pharmacists"
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Document(collection = "pharmacists")
public class Pharmacist {

    @Id
    private String id;

    // ---- Auth fields ----
    @Indexed(unique = true)
    @NotBlank(message = "Username is required")
    private String username;

    @NotBlank(message = "Password is required")
    private String password;

    private Role role = Role.PHARMACIST;

    // ---- Profile fields ----
    @NotBlank(message = "Full name is required")
    private String fullName;

    @Email(message = "Email should be valid")
    private String email;

    private String phoneNumber;

    private String licenseNumber;
}
