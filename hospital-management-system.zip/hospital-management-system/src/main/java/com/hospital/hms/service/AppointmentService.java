package com.hospital.hms.service;

import com.hospital.hms.document.Appointment;
import com.hospital.hms.document.AppointmentStatus;
import com.hospital.hms.document.Doctor;
import com.hospital.hms.document.Patient;
import com.hospital.hms.dto.AppointmentRequest;
import com.hospital.hms.repository.AppointmentRepository;
import com.hospital.hms.repository.DoctorRepository;
import com.hospital.hms.repository.PatientRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AppointmentService {

    private final AppointmentRepository appointmentRepository;
    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;

    // ── Book new appointment ──────────────────────────────────────

    public Appointment bookAppointment(AppointmentRequest request) {
        Patient patient = patientRepository.findById(request.getPatientId())
                .orElseThrow(() -> new IllegalArgumentException(
                        "Patient not found with ID: " + request.getPatientId()));

        Doctor doctor = doctorRepository.findById(request.getDoctorId())
                .orElseThrow(() -> new IllegalArgumentException(
                        "Doctor not found with ID: " + request.getDoctorId()));

        // Double-booking check
        boolean slotTaken = appointmentRepository
                .existsByDoctorIdAndAppointmentDateAndAppointmentTime(
                        request.getDoctorId(),
                        request.getAppointmentDate(),
                        request.getAppointmentTime());
        if (slotTaken) {
            throw new IllegalArgumentException(
                    "This time slot is already booked for the selected doctor");
        }

        Appointment appointment = new Appointment();
        appointment.setPatientId(request.getPatientId());
        appointment.setDoctorId(request.getDoctorId());
        appointment.setAppointmentDate(request.getAppointmentDate());
        appointment.setAppointmentTime(request.getAppointmentTime());
        appointment.setReasonForVisit(request.getReasonForVisit());
        appointment.setNotes(request.getNotes());
        appointment.setStatus(AppointmentStatus.SCHEDULED);
        appointment.setCreatedAt(LocalDateTime.now().toString());

        // Denormalized names for quick list display
        appointment.setPatientName(patient.getFullName());
        appointment.setDoctorName(doctor.getFullName());

        return appointmentRepository.save(appointment);
    }

    // ── Get all appointments (Admin) ─────────────────────────────

    public List<Appointment> getAllAppointments() {
        return appointmentRepository.findAll();
    }

    // ── Get single appointment ───────────────────────────────────

    public Appointment getAppointmentById(String id) {
        return appointmentRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException(
                        "Appointment not found with ID: " + id));
    }

    // ── Patient's appointment history ────────────────────────────

    public List<Appointment> getAppointmentsByPatient(String patientId) {
        return appointmentRepository.findByPatientId(patientId);
    }

    // ── Doctor's full schedule ───────────────────────────────────

    public List<Appointment> getAppointmentsByDoctor(String doctorId) {
        return appointmentRepository.findByDoctorId(doctorId);
    }

    // ── Doctor's schedule for a specific date ────────────────────

    public List<Appointment> getDoctorScheduleForDate(String doctorId, LocalDate date) {
        return appointmentRepository.findByDoctorIdAndAppointmentDate(doctorId, date);
    }

    // ── Update appointment status ────────────────────────────────

    public Appointment updateStatus(String id, AppointmentStatus newStatus) {
        Appointment appointment = getAppointmentById(id);
        appointment.setStatus(newStatus);
        return appointmentRepository.save(appointment);
    }

    // ── Cancel appointment ───────────────────────────────────────

    public Appointment cancelAppointment(String id) {
        return updateStatus(id, AppointmentStatus.CANCELLED);
    }

    // ── Delete appointment (Admin only) ─────────────────────────

    public void deleteAppointment(String id) {
        Appointment appointment = getAppointmentById(id);
        appointmentRepository.delete(appointment);
    }
}
