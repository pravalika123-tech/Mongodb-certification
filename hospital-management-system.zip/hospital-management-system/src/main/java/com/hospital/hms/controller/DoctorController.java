package com.hospital.hms.controller;

import com.hospital.hms.document.Doctor;
import com.hospital.hms.dto.ApiResponse;
import com.hospital.hms.repository.DoctorRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/doctors")
@RequiredArgsConstructor
@Tag(name = "Doctors", description = "Doctor profile and search")
@SecurityRequirement(name = "bearerAuth")
public class DoctorController {

    private final DoctorRepository doctorRepository;

    @Operation(summary = "Get all doctors")
    @PreAuthorize("hasAnyRole('ADMIN','RECEPTIONIST','PATIENT')")
    @GetMapping
    public ResponseEntity<ApiResponse> getAllDoctors() {
        List<Doctor> doctors = doctorRepository.findAll();
        // Clear passwords before returning
        doctors.forEach(d -> d.setPassword(null));
        return ResponseEntity.ok(ApiResponse.ok("Doctors retrieved", doctors));
    }

    @Operation(summary = "Get doctor by ID")
    @PreAuthorize("hasAnyRole('ADMIN','RECEPTIONIST','PATIENT','DOCTOR')")
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse> getDoctorById(@PathVariable String id) {
        Doctor doctor = doctorRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Doctor not found: " + id));
        doctor.setPassword(null);
        return ResponseEntity.ok(ApiResponse.ok("Doctor retrieved", doctor));
    }

    @Operation(summary = "Search doctors by specialization")
    @PreAuthorize("hasAnyRole('ADMIN','RECEPTIONIST','PATIENT')")
    @GetMapping("/search")
    public ResponseEntity<ApiResponse> searchBySpecialization(
            @RequestParam String specialization) {
        List<Doctor> doctors = doctorRepository.findBySpecializationIgnoreCase(specialization);
        doctors.forEach(d -> d.setPassword(null));
        return ResponseEntity.ok(ApiResponse.ok("Doctors found", doctors));
    }

    @Operation(summary = "Delete a doctor (Admin only)")
    @PreAuthorize("hasRole('ADMIN')")
    @DeleteMapping("/{id}")
    public ResponseEntity<ApiResponse> deleteDoctor(@PathVariable String id) {
        Doctor doctor = doctorRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Doctor not found: " + id));
        doctorRepository.delete(doctor);
        return ResponseEntity.ok(ApiResponse.ok("Doctor deleted"));
    }
}
