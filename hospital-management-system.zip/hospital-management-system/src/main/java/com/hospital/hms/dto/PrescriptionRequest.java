package com.hospital.hms.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

@Data
public class PrescriptionRequest {

    @NotBlank(message = "Appointment ID is required")
    private String appointmentId;

    @NotBlank(message = "Patient ID is required")
    private String patientId;

    @NotEmpty(message = "At least one medicine is required")
    private List<MedicineRequest> medicines;

    private String diagnosis;

    private String additionalNotes;

    @Data
    public static class MedicineRequest {
        private String name;
        private String dosage;
        private String frequency;
        private String duration;
        private String instructions;
    }
}
