package com.hospital.hms.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import lombok.Data;

import java.util.List;

@Data
public class BillingRequest {

    @NotBlank(message = "Patient ID is required")
    private String patientId;

    private String appointmentId;

    @NotEmpty(message = "At least one billing item is required")
    private List<BillItemRequest> items;

    private String paymentMethod;

    @Data
    public static class BillItemRequest {
        private String description;
        private double amount;
        private int quantity = 1;
    }
}
